package com.portable.newsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
